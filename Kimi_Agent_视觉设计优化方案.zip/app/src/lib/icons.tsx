import {
  UtensilsCrossed, Sofa, Baby, Droplets, Cat, Shirt, Smartphone,
  Sparkles, Bus, Gamepad2, HeartPulse, MoreHorizontal, Coffee,
  List, Wallet, PieChart, Settings, Plus, ChevronLeft, ChevronRight,
  ChevronDown, Eye, EyeOff, Search, X, Calendar, Banknote, CreditCard,
  Camera, TrendingUp, ArrowUpDown, Filter, Trash2, Edit3, Check,
  Home, Receipt
} from 'lucide-react';

const iconMap: Record<string, React.ComponentType<{ size?: number; strokeWidth?: number; className?: string }>> = {
  UtensilsCrossed, Sofa, Baby, Droplets, Cat, Shirt, Smartphone,
  Sparkles, Bus, Gamepad2, HeartPulse, MoreHorizontal, Coffee,
  List, Wallet, PieChart, Settings, Plus, ChevronLeft, ChevronRight,
  ChevronDown, Eye, EyeOff, Search, X, Calendar, Banknote, CreditCard,
  Camera, TrendingUp, ArrowUpDown, Filter, Trash2, Edit3, Check,
  Home, Receipt
};

export function getIcon(name: string) {
  return iconMap[name] || MoreHorizontal;
}

export {
  UtensilsCrossed, Sofa, Baby, Droplets, Cat, Shirt, Smartphone,
  Sparkles, Bus, Gamepad2, HeartPulse, MoreHorizontal, Coffee,
  List, Wallet, PieChart, Settings, Plus, ChevronLeft, ChevronRight,
  ChevronDown, Eye, EyeOff, Search, X, Calendar, Banknote, CreditCard,
  Camera, TrendingUp, ArrowUpDown, Filter, Trash2, Edit3, Check,
  Home, Receipt
};
