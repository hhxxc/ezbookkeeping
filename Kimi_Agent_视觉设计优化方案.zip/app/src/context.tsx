import React, { createContext, useContext, useReducer, useEffect } from 'react';
import type { AppState, Action } from './types';
import { loadState, saveState } from './data';

const initialState = loadState();

function appReducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'ADD_TRANSACTION':
      return { ...state, transactions: [action.payload, ...state.transactions] };
    case 'EDIT_TRANSACTION': {
      const { id, updates } = action.payload;
      return {
        ...state,
        transactions: state.transactions.map((t) =>
          t.id === id ? { ...t, ...updates } : t
        ),
      };
    }
    case 'DELETE_TRANSACTION':
      return {
        ...state,
        transactions: state.transactions.filter((t) => t.id !== action.payload),
      };
    case 'SET_MONTH':
      return { ...state, selectedMonth: action.payload };
    case 'SET_TAB':
      return { ...state, selectedTab: action.payload };
    case 'SET_BUDGET':
      return { ...state, budget: action.payload };
    case 'ADD_ACCOUNT':
      return { ...state, accounts: [...state.accounts, action.payload] };
    case 'TOGGLE_AMOUNT_VISIBILITY':
      return { ...state, hideAmounts: !state.hideAmounts };
    case 'LOAD_STATE':
      return action.payload;
    default:
      return state;
  }
}

interface AppContextValue {
  state: AppState;
  dispatch: React.Dispatch<Action>;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  useEffect(() => {
    saveState(state);
  }, [state]);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}

export function useMonthlyTransactions(month: string) {
  const { state } = useApp();
  return state.transactions.filter((t) => t.date.startsWith(month));
}

export function useCategoryBreakdown(month: string, type: 'expense' | 'income') {
  const monthlyTx = useMonthlyTransactions(month);
  const { state } = useApp();

  const filtered = monthlyTx.filter((t) => t.type === type);
  const total = filtered.reduce((sum, t) => sum + t.amount, 0);

  const breakdown = state.categories
    .filter((cat) => !cat.parent)
    .map((cat) => {
      const catTx = filtered.filter((t) => {
        const tCat = state.categories.find((c) => c.key === t.category);
        return t.category === cat.key || tCat?.parent === cat.key;
      });
      const catTotal = catTx.reduce((sum, t) => sum + t.amount, 0);
      return {
        ...cat,
        amount: catTotal,
        percentage: total > 0 ? (catTotal / total) * 100 : 0,
        count: catTx.length,
      };
    })
    .filter((c) => c.amount > 0)
    .sort((a, b) => b.amount - a.amount);

  return { total, breakdown };
}

export function useTimePeriodStats() {
  const { state } = useApp();
  const now = new Date();
  const today = now.toISOString().split('T')[0];

  const todayTx = state.transactions.filter((t) => t.date === today);
  const todayExpense = todayTx.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const todayIncome = todayTx.filter((t) => t.type === 'income').reduce((s, t) => s + t.amount, 0);

  const weekStart = new Date(now);
  weekStart.setDate(now.getDate() - now.getDay() + 1);
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekStart.getDate() + 6);
  const weekTx = state.transactions.filter((t) => t.date >= weekStart.toISOString().split('T')[0] && t.date <= weekEnd.toISOString().split('T')[0]);
  const weekExpense = weekTx.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const weekIncome = weekTx.filter((t) => t.type === 'income').reduce((s, t) => s + t.amount, 0);

  const monthStr = today.slice(0, 7);
  const monthTx = state.transactions.filter((t) => t.date.startsWith(monthStr));
  const monthExpense = monthTx.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const monthIncome = monthTx.filter((t) => t.type === 'income').reduce((s, t) => s + t.amount, 0);

  const yearStr = today.slice(0, 4);
  const yearTx = state.transactions.filter((t) => t.date.startsWith(yearStr));
  const yearExpense = yearTx.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const yearIncome = yearTx.filter((t) => t.type === 'income').reduce((s, t) => s + t.amount, 0);

  return {
    today: { expense: todayExpense, income: todayIncome, label: '今天', sublabel: `${now.getMonth() + 1}月${now.getDate()}日` },
    week: { expense: weekExpense, income: weekIncome, label: '本周', sublabel: `${weekStart.getMonth() + 1}月${weekStart.getDate()}日 - ${weekEnd.getMonth() + 1}月${weekEnd.getDate()}日` },
    month: { expense: monthExpense, income: monthIncome, label: '本月', sublabel: `${now.getMonth() + 1}月1日 - ${now.getMonth() + 1}月${new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate()}日` },
    year: { expense: yearExpense, income: yearIncome, label: '今年', sublabel: `${now.getFullYear()}年` },
  };
}
