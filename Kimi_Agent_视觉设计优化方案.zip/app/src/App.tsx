import { Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { AppProvider } from '@/context';
import ToastContainer from '@/components/Toast';
import BottomNav from '@/components/BottomNav';
import FAB from '@/components/FAB';
import HomePage from '@/pages/HomePage';
import StatisticsPage from '@/pages/StatisticsPage';
import TransactionsPage from '@/pages/TransactionsPage';
import AddTransactionPage from '@/pages/AddTransactionPage';
import AccountsPage from '@/pages/AccountsPage';
import SettingsPage from '@/pages/SettingsPage';

const navRoutes = ['/', '/statistics', '/transactions', '/accounts', '/settings'];

function PageWrapper({ children }: { children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.25, ease: 'easeOut' }}
      className="w-full"
    >
      {children}
    </motion.div>
  );
}

export default function App() {
  const location = useLocation();
  const showNav = navRoutes.includes(location.pathname);
  const showFab = showNav;

  return (
    <AppProvider>
      <div className="min-h-screen bg-neutral-100">
        <div className="max-w-[430px] mx-auto bg-bg min-h-screen relative shadow-xl">
          <AnimatePresence mode="wait">
            <Routes location={location} key={location.pathname}>
              <Route
                path="/"
                element={
                  <PageWrapper>
                    <HomePage />
                  </PageWrapper>
                }
              />
              <Route
                path="/statistics"
                element={
                  <PageWrapper>
                    <StatisticsPage />
                  </PageWrapper>
                }
              />
              <Route
                path="/transactions"
                element={
                  <PageWrapper>
                    <TransactionsPage />
                  </PageWrapper>
                }
              />
              <Route
                path="/add"
                element={
                  <PageWrapper>
                    <AddTransactionPage />
                  </PageWrapper>
                }
              />
              <Route
                path="/accounts"
                element={
                  <PageWrapper>
                    <AccountsPage />
                  </PageWrapper>
                }
              />
              <Route
                path="/settings"
                element={
                  <PageWrapper>
                    <SettingsPage />
                  </PageWrapper>
                }
              />
            </Routes>
          </AnimatePresence>

          <ToastContainer />
          {showFab && <FAB />}
          {showNav && <BottomNav />}
        </div>
      </div>
    </AppProvider>
  );
}
