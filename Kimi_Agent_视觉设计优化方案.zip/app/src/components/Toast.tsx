import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface Toast {
  id: string;
  message: string;
  type?: 'success' | 'info' | 'error';
}

let toastQueue: ((toast: Toast) => void) | null = null;

export function showToast(message: string, type: Toast['type'] = 'info') {
  if (toastQueue) {
    toastQueue({ id: Date.now().toString(), message, type });
  }
}

export default function ToastContainer() {
  const [toasts, setToasts] = useState<Toast[]>([]);

  useEffect(() => {
    toastQueue = (toast: Toast) => {
      setToasts((prev) => [...prev, toast]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== toast.id));
      }, 2500);
    };
    return () => { toastQueue = null; };
  }, []);

  const bgMap = {
    success: 'bg-brand',
    info: 'bg-gray-800',
    error: 'bg-expense',
  };

  return (
    <div className="fixed top-20 left-0 right-0 z-[100] flex flex-col items-center gap-2 pointer-events-none">
      <AnimatePresence>
        {toasts.map((toast) => (
          <motion.div
            key={toast.id}
            initial={{ opacity: 0, y: -20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.9 }}
            className={`px-4 py-2.5 rounded-xl text-white text-sm font-medium shadow-dropdown pointer-events-auto ${bgMap[toast.type || 'info']}`}
          >
            {toast.message}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
