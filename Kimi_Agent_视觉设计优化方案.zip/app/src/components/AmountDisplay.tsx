import { motion } from 'framer-motion';
import { Eye, EyeOff } from 'lucide-react';
import { useApp } from '@/context';

interface AmountDisplayProps {
  amount: number;
  type?: 'expense' | 'income';
  size?: 'sm' | 'md' | 'lg';
  prefix?: string;
  className?: string;
  showToggle?: boolean;
}

export default function AmountDisplay({
  amount,
  type = 'expense',
  size = 'md',
  prefix = '¥',
  className = '',
  showToggle = false,
}: AmountDisplayProps) {
  const { state, dispatch } = useApp();
  const hidden = state.hideAmounts;

  const sizeClasses = {
    sm: 'text-base',
    md: 'text-2xl',
    lg: 'text-4xl leading-tight',
  };

  const colorClass = type === 'expense' ? 'text-expense' : 'text-income';
  const formatted = new Intl.NumberFormat('zh-CN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <motion.span
        className={`font-din ${sizeClasses[size]} ${colorClass}`}
        key={hidden ? 'hidden' : amount}
        initial={{ opacity: 0, scale: 1.1 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.2 }}
      >
        {prefix && <span className="text-[0.7em] mr-0.5">{prefix}</span>}
        {hidden ? '****' : formatted}
      </motion.span>
      {showToggle && (
        <button
          onClick={() => dispatch({ type: 'TOGGLE_AMOUNT_VISIBILITY' })}
          className="text-text-tertiary hover:text-text-secondary transition-colors"
        >
          {hidden ? <EyeOff size={18} /> : <Eye size={18} />}
        </button>
      )}
    </div>
  );
}
