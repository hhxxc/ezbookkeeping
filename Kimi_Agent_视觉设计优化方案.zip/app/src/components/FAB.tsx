import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Plus } from 'lucide-react';

export default function FAB() {
  const navigate = useNavigate();

  return (
    <motion.button
      onClick={() => navigate('/add')}
      className="fixed z-50 bottom-24 right-5 w-14 h-14 rounded-full bg-brand flex items-center justify-center shadow-fab"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.92 }}
      transition={{ type: 'spring', stiffness: 400, damping: 17 }}
    >
      <Plus size={24} strokeWidth={2.5} className="text-white" />
    </motion.button>
  );
}
