import { getIcon } from '@/lib/icons';

interface CategoryIconProps {
  iconName: string;
  color: string;
  size?: number;
  className?: string;
}

export default function CategoryIcon({ iconName, color, size = 22, className = '' }: CategoryIconProps) {
  const Icon = getIcon(iconName);
  const isLight = (hex: string) => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return (r * 299 + g * 587 + b * 114) / 1000 > 128;
  };

  return (
    <div
      className={`flex items-center justify-center rounded-[10px] ${className}`}
      style={{ backgroundColor: color, width: size + 18, height: size + 18 }}
    >
      <Icon size={size} strokeWidth={1.5} className={isLight(color) ? 'text-gray-700' : 'text-white'} />
    </div>
  );
}
