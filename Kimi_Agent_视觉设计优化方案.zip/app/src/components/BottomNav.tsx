import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { List, Wallet, PieChart, Settings } from 'lucide-react';

const tabs = [
  { key: '/', label: '明细', icon: List },
  { key: '/accounts', label: '账户', icon: Wallet },
  { key: '/statistics', label: '统计', icon: PieChart },
  { key: '/settings', label: '设置', icon: Settings },
];

export default function BottomNav() {
  const location = useLocation();
  const navigate = useNavigate();
  const current = location.pathname;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white rounded-t-3xl shadow-nav pb-safe">
      <div className="max-w-[430px] mx-auto flex items-center justify-around h-16 px-2">
        {tabs.map((tab) => {
          const isActive = current === tab.key;
          const Icon = tab.icon;
          return (
            <button
              key={tab.key}
              onClick={() => navigate(tab.key)}
              className="flex flex-col items-center justify-center gap-0.5 w-16 h-14 relative"
            >
              <Icon
                size={22}
                strokeWidth={1.5}
                className={isActive ? 'text-brand' : 'text-text-tertiary'}
              />
              <span
                className={`text-[11px] font-medium ${
                  isActive ? 'text-brand' : 'text-text-tertiary'
                }`}
              >
                {tab.label}
              </span>
              {isActive && (
                <motion.div
                  layoutId="nav-dot"
                  className="absolute -bottom-0.5 w-1 h-1 rounded-full bg-brand"
                  transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
