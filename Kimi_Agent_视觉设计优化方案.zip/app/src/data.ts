import type { Transaction, Account, Category, AppState } from './types';
import { CATEGORY_MAP } from './types';

export const DEMO_TRANSACTIONS: Transaction[] = [
  {
    id: 't1',
    amount: 6.88,
    type: 'expense',
    category: 'drink',
    description: '千店同庆 | 6.9元喝茶百道爆款拿铁3选1',
    account: 'alipay',
    date: '2026-05-14',
    time: '13:54',
    tags: ['饮食'],
  },
  {
    id: 't2',
    amount: 112.60,
    type: 'expense',
    category: 'pet',
    description: '购买阿飞和巴弟E76全价益生菌猫粮',
    account: 'alipay',
    date: '2026-05-14',
    time: '10:29',
    tags: ['其他'],
  },
  {
    id: 't3',
    amount: 5.99,
    type: 'expense',
    category: 'drink',
    description: '肯德基咖啡拿铁美式特惠',
    account: 'wechat',
    date: '2026-05-14',
    time: '07:33',
    tags: ['饮食'],
  },
  {
    id: 't4',
    amount: 5.99,
    type: 'expense',
    category: 'food',
    description: '肯德基咖啡拿铁',
    account: 'wechat',
    date: '2026-05-13',
    time: '13:20',
    tags: ['饮食'],
  },
  {
    id: 't5',
    amount: 4.35,
    type: 'expense',
    category: 'home',
    description: '购买棉细布【锁边】,51*51【三张】',
    account: 'alipay',
    date: '2026-05-13',
    time: '08:25',
    tags: ['日用'],
  },
  {
    id: 't6',
    amount: 919.76,
    type: 'expense',
    category: 'home',
    description: '宜家储物柜套装',
    account: 'debit',
    date: '2026-05-10',
    time: '15:30',
    tags: ['家居'],
  },
  {
    id: 't7',
    amount: 837.66,
    type: 'expense',
    category: 'baby',
    description: '婴儿奶粉3段',
    account: 'alipay',
    date: '2026-05-08',
    time: '11:20',
    tags: ['育儿'],
  },
  {
    id: 't8',
    amount: 486.05,
    type: 'expense',
    category: 'utilities',
    description: '5月电费',
    account: 'alipay',
    date: '2026-05-05',
    time: '09:00',
    tags: ['账单'],
  },
  {
    id: 't9',
    amount: 863.79,
    type: 'expense',
    category: 'food',
    description: '山姆会员店采购',
    account: 'credit',
    date: '2026-05-03',
    time: '14:00',
    tags: ['食品'],
  },
  {
    id: 't10',
    amount: 59.80,
    type: 'expense',
    category: 'clothing',
    description: '优衣库T恤',
    account: 'wechat',
    date: '2026-05-02',
    time: '16:45',
    tags: ['服饰'],
  },
  {
    id: 't11',
    amount: 55.69,
    type: 'expense',
    category: 'electronics',
    description: '手机充电线',
    account: 'alipay',
    date: '2026-05-01',
    time: '10:10',
    tags: ['电子'],
  },
  {
    id: 't12',
    amount: 45.00,
    type: 'expense',
    category: 'service',
    description: '每周保洁服务',
    account: 'cash',
    date: '2026-04-28',
    time: '08:00',
    tags: ['家政'],
  },
  {
    id: 't13',
    amount: 320.00,
    type: 'expense',
    category: 'transport',
    description: '加油',
    account: 'alipay',
    date: '2026-04-25',
    time: '18:30',
    tags: ['交通'],
  },
  {
    id: 't14',
    amount: 128.00,
    type: 'expense',
    category: 'entertainment',
    description: '电影票2张',
    account: 'wechat',
    date: '2026-04-20',
    time: '19:00',
    tags: ['娱乐'],
  },
  {
    id: 't15',
    amount: 280.00,
    type: 'expense',
    category: 'medical',
    description: '体检费用',
    account: 'alipay',
    date: '2026-04-15',
    time: '09:30',
    tags: ['医疗'],
  },
  {
    id: 't16',
    amount: 18.50,
    type: 'expense',
    category: 'other',
    description: '快递费',
    account: 'cash',
    date: '2026-04-10',
    time: '14:20',
    tags: ['其他'],
  },
  {
    id: 't17',
    amount: 5000.00,
    type: 'income',
    category: 'other',
    description: '工资收入',
    account: 'debit',
    date: '2026-05-10',
    time: '09:00',
    tags: ['工资'],
  },
];

export const DEMO_ACCOUNTS: Account[] = [
  { id: 'cash', name: '现金', type: 'cash', balance: 1200.50, icon: 'Banknote', color: '#A8D5BA' },
  { id: 'debit', name: '储蓄卡', type: 'debit', balance: 28560.00, icon: 'CreditCard', color: '#B8C5D6' },
  { id: 'credit', name: '信用卡', type: 'credit', balance: -3500.00, icon: 'CreditCard', color: '#F5B8B8' },
  { id: 'alipay', name: '支付宝', type: 'ewallet', balance: 5680.30, icon: 'Wallet', color: '#3DC9A0' },
  { id: 'wechat', name: '微信支付', type: 'ewallet', balance: 2340.20, icon: 'Smartphone', color: '#B8D4E3' },
];

export const CATEGORIES: Category[] = Object.values(CATEGORY_MAP);

export const DEFAULT_STATE: AppState = {
  transactions: DEMO_TRANSACTIONS,
  selectedMonth: '2026-05',
  selectedTab: 'expense',
  budget: 5000,
  accounts: DEMO_ACCOUNTS,
  categories: CATEGORIES,
  hideAmounts: false,
};

export function loadState(): AppState {
  try {
    const raw = localStorage.getItem('nestnote_data');
    if (raw) {
      return JSON.parse(raw);
    }
  } catch {
    // ignore
  }
  return DEFAULT_STATE;
}

export function saveState(state: AppState) {
  try {
    localStorage.setItem('nestnote_data', JSON.stringify(state));
  } catch {
    // ignore
  }
}
