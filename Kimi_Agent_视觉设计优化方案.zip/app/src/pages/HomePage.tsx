import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Eye, EyeOff, ChevronRight } from 'lucide-react';
import { useApp, useTimePeriodStats } from '@/context';
import { TAB_LABELS } from '@/types';
import { formatAmount } from '@/lib/utils';
import RingProgress from '@/components/RingProgress';
import { getIcon } from '@/lib/icons';

const quickFilters = ['全部', '餐饮', '交通', '购物', '娱乐', '家居'];

const tabConfig = [
  { key: 'expense' as const, label: '支出' },
  { key: 'income' as const, label: '收入' },
  { key: 'balance' as const, label: '结余' },
];

export default function HomePage() {
  const { state, dispatch } = useApp();
  const navigate = useNavigate();
  const timeStats = useTimePeriodStats();
  const [expandedPeriod, setExpandedPeriod] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState('全部');

  const monthlyTx = useMemo(() =>
    state.transactions.filter((t) => t.date.startsWith(state.selectedMonth)),
    [state.transactions, state.selectedMonth]
  );

  const monthTotal = useMemo(() => {
    const expense = monthlyTx.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
    const income = monthlyTx.filter((t) => t.type === 'income').reduce((s, t) => s + t.amount, 0);
    return { expense, income, balance: income - expense };
  }, [monthlyTx]);

  const budgetProgress = useMemo(() => {
    if (!state.budget || state.budget <= 0) return null;
    return Math.min((monthTotal.expense / state.budget) * 100, 100);
  }, [monthTotal.expense, state.budget]);

  const totalMap = {
    expense: monthTotal.expense,
    income: monthTotal.income,
    balance: monthTotal.balance,
  };

  const periods = [
    { key: 'today', ...timeStats.today },
    { key: 'week', ...timeStats.week },
    { key: 'month', ...timeStats.month },
    { key: 'year', ...timeStats.year },
  ];

  const periodIcons: Record<string, string> = {
    today: 'CalendarDays',
    week: 'CalendarDays',
    month: 'TrendingUp',
    year: 'TrendingUp',
  };

  return (
    <div className="min-h-screen bg-bg pb-28">
      {/* Header */}
      <div className="pt-4 pb-3 px-5">
        <h1 className="text-center text-[22px] font-semibold text-text-primary">巢记</h1>
      </div>

      {/* Tab Switcher */}
      <div className="flex justify-center gap-2 px-5 mb-4">
        {tabConfig.map((tab) => (
          <motion.button
            key={tab.key}
            onClick={() => dispatch({ type: 'SET_TAB', payload: tab.key })}
            className={`px-5 py-2 rounded-lg text-sm font-medium transition-colors ${
              state.selectedTab === tab.key
                ? 'bg-brand-light text-brand'
                : 'text-text-secondary hover:text-text-primary'
            }`}
            whileTap={{ scale: 0.95 }}
            transition={{ type: 'spring', stiffness: 500, damping: 30 }}
          >
            {tab.label}
          </motion.button>
        ))}
      </div>

      {/* Overview Card */}
      <div className="mx-5 bg-white rounded-2xl shadow-card p-5 mb-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <p className="text-sm text-text-secondary mb-1">
              {parseInt(state.selectedMonth.split('-')[1])}月 · {TAB_LABELS[state.selectedTab]}
            </p>
            <div className="flex items-center gap-2">
              <AnimatePresence mode="wait">
                <motion.div
                  key={state.selectedTab}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.2 }}
                  className="flex items-center gap-2"
                >
                  <span className="text-sm text-text-secondary">¥</span>
                  <span className="text-4xl font-din font-bold text-text-primary tracking-wide">
                    {state.hideAmounts ? '****' : formatAmount(totalMap[state.selectedTab])}
                  </span>
                </motion.div>
              </AnimatePresence>
              <button
                onClick={() => dispatch({ type: 'TOGGLE_AMOUNT_VISIBILITY' })}
                className="text-text-tertiary hover:text-text-secondary transition-colors mt-1"
              >
                {state.hideAmounts ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            {state.selectedTab === 'expense' && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-sm text-text-secondary mt-2"
              >
                当月收入 ¥ {state.hideAmounts ? '****' : formatAmount(monthTotal.income)}
              </motion.p>
            )}
          </div>
          {budgetProgress !== null && (
            <div className="flex flex-col items-center gap-1">
              <RingProgress percentage={budgetProgress} size={52} strokeWidth={4} />
              <span className="text-[10px] text-text-tertiary">
                {Math.round(budgetProgress)}%
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Quick Filters */}
      <div className="px-5 mb-4">
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          {quickFilters.map((f) => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              className={`px-4 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                activeFilter === f
                  ? 'bg-brand-light text-brand'
                  : 'bg-white text-text-secondary border border-divider'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Time Period Cards */}
      <div className="mx-5 bg-white rounded-2xl shadow-card overflow-hidden">
        {periods.map((period, i) => {
          const Icon = getIcon(periodIcons[period.key] || 'CalendarDays');
          const isExpanded = expandedPeriod === period.key;
          return (
            <div key={period.key}>
              <motion.button
                onClick={() => setExpandedPeriod(isExpanded ? null : period.key)}
                className="w-full flex items-center gap-3 px-5 py-4 text-left hover:bg-gray-50 transition-colors"
                whileTap={{ scale: 0.99 }}
              >
                <div className="w-11 h-11 rounded-xl bg-bg flex items-center justify-center flex-shrink-0">
                  <Icon size={20} strokeWidth={1.5} className="text-text-secondary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[15px] font-medium text-text-primary">{period.label}</p>
                  <p className="text-xs text-text-tertiary mt-0.5">{period.sublabel}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-sm font-din text-expense">
                    ¥ {state.hideAmounts ? '****' : formatAmount(period.expense)}
                  </p>
                  <p className="text-sm font-din text-income">
                    ¥ {state.hideAmounts ? '****' : formatAmount(period.income)}
                  </p>
                </div>
                <motion.div
                  animate={{ rotate: isExpanded ? 90 : 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <ChevronRight size={16} className="text-divider" />
                </motion.div>
              </motion.button>
              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3, ease: 'easeOut' }}
                    className="overflow-hidden"
                  >
                    <div className="px-5 pb-4 pt-1">
                      {/* Show mini transaction list for this period */}
                      <div className="bg-bg rounded-xl p-3 space-y-2">
                        <p className="text-xs text-text-tertiary">
                          {period.label}共 {period.expense > 0 ? '有支出记录' : '无支出记录'}
                        </p>
                        <button
                          onClick={() => navigate('/transactions')}
                          className="text-sm text-brand font-medium hover:underline"
                        >
                          查看明细 →
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
              {i < periods.length - 1 && <div className="h-px bg-divider mx-5" />}
            </div>
          );
        })}
      </div>
    </div>
  );
}
