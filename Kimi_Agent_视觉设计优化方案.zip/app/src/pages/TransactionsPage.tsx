import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronDown, Search, X, Plus } from 'lucide-react';
import { useApp } from '@/context';
import { CATEGORY_MAP } from '@/types';
import { formatAmount, getWeekDay } from '@/lib/utils';
import CategoryIcon from '@/components/CategoryIcon';

const hotTags = ['餐饮', '交通', '购物', '本月大额'];

export default function TransactionsPage() {
  const navigate = useNavigate();
  const { state } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchTags, setShowSearchTags] = useState(false);

  const monthlyTx = useMemo(() => {
    let tx = state.transactions.filter((t) => t.date.startsWith(state.selectedMonth));
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      tx = tx.filter(
        (t) =>
          t.description.toLowerCase().includes(q) ||
          t.amount.toString().includes(q) ||
          CATEGORY_MAP[t.category]?.name.includes(q)
      );
    }
    return tx.sort((a, b) => b.date.localeCompare(a.date) || b.time.localeCompare(a.time));
  }, [state.transactions, state.selectedMonth, searchQuery]);

  const monthIncome = monthlyTx.filter((t) => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const monthExpense = monthlyTx.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0);

  const groupedByDate = useMemo(() => {
    const groups: Record<string, typeof monthlyTx> = {};
    monthlyTx.forEach((t) => {
      if (!groups[t.date]) groups[t.date] = [];
      groups[t.date].push(t);
    });
    return Object.entries(groups);
  }, [monthlyTx]);

  return (
    <div className="min-h-screen bg-bg pb-20">
      {/* Top Bar */}
      <div className="bg-white px-4 pt-4 pb-3 flex items-center justify-between shadow-xs">
        <button onClick={() => navigate('/')} className="p-2 -ml-2">
          <ChevronLeft size={24} strokeWidth={1.5} className="text-text-primary" />
        </button>
        <button className="flex items-center gap-1 text-[17px] font-semibold text-text-primary">
          交易列表
          <ChevronDown size={18} className="text-text-tertiary" />
        </button>
        <button onClick={() => navigate('/add')} className="p-2 -mr-2">
          <Plus size={24} strokeWidth={1.5} className="text-text-primary" />
        </button>
      </div>

      {/* Search Bar */}
      <div className="px-4 pt-3 pb-2">
        <div className="relative">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-tertiary" />
          <input
            type="text"
            placeholder="搜索交易描述、金额或分类"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onFocus={() => setShowSearchTags(true)}
            className="w-full h-11 pl-10 pr-10 bg-white rounded-xl border border-divider text-sm focus:outline-none focus:border-brand transition-colors"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2"
            >
              <X size={16} className="text-text-tertiary" />
            </button>
          )}
        </div>
        {/* Hot Tags */}
        <AnimatePresence>
          {showSearchTags && !searchQuery && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="flex gap-2 mt-2 flex-wrap">
                {hotTags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => { setSearchQuery(tag); setShowSearchTags(false); }}
                    className="px-3 py-1 bg-white rounded-lg text-xs text-text-secondary border border-divider"
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Monthly Summary */}
      <div className="px-4 py-2 flex items-center justify-between">
        <span className="text-sm font-medium text-text-primary">
          {state.selectedMonth.replace('-', '年')}月
        </span>
        <div className="flex items-center gap-3">
          <span className="text-sm text-income">+¥{formatAmount(monthIncome)}</span>
          <span className="text-sm text-expense">-¥{formatAmount(monthExpense)}</span>
        </div>
      </div>

      {/* Transaction List */}
      <div className="px-4 space-y-3">
        {groupedByDate.map(([date, txs]) => {
          const dayExpense = txs.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
          const dayIncome = txs.filter((t) => t.type === 'income').reduce((s, t) => s + t.amount, 0);
          return (
            <div key={date} className="bg-white rounded-2xl shadow-card overflow-hidden">
              {/* Date Header */}
              <div className="flex items-center justify-between px-4 pt-3 pb-2">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-text-primary">{date.split('-')[2]}</span>
                  <span className="text-[11px] text-text-tertiary">{getWeekDay(date)}</span>
                </div>
                <div className="flex items-center gap-2">
                  {dayIncome > 0 && <span className="text-xs text-income">+{formatAmount(dayIncome)}</span>}
                  {dayExpense > 0 && <span className="text-xs text-expense">-{formatAmount(dayExpense)}</span>}
                </div>
              </div>

              {/* Transaction Items */}
              {txs.map((tx, i) => {
                const cat = CATEGORY_MAP[tx.category] || CATEGORY_MAP.other;
                return (
                  <div key={tx.id}>
                    <div className="flex items-start gap-3 px-4 py-3">
                      <CategoryIcon iconName={cat.icon} color={cat.color} size={18} className="mt-0.5 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-0.5">
                          <p className="text-[15px] font-medium text-text-primary truncate">{tx.description.split('|')[0].trim()}</p>
                          <span className={`text-[15px] font-din font-semibold flex-shrink-0 ml-2 ${
                            tx.type === 'expense' ? 'text-expense' : 'text-income'
                          }`}>
                            {tx.type === 'expense' ? '-' : '+'}¥{formatAmount(tx.amount)}
                          </span>
                        </div>
                        <p className="text-[13px] text-text-secondary truncate">{tx.description}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="px-1.5 py-0.5 bg-brand-light text-brand text-[11px] rounded">
                            {cat.name}
                          </span>
                          <span className="text-[11px] text-text-tertiary">
                            {tx.time} · {tx.account === 'alipay' ? '支付宝' : tx.account === 'wechat' ? '微信' : '现金'}
                          </span>
                        </div>
                      </div>
                      <ChevronLeft size={14} className="text-divider rotate-180 flex-shrink-0 mt-1" />
                    </div>
                    {i < txs.length - 1 && <div className="h-px bg-divider ml-[60px]" />}
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>

      {groupedByDate.length === 0 && (
        <div className="text-center py-16">
          <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-bg flex items-center justify-center">
            <Search size={32} className="text-divider" />
          </div>
          <p className="text-sm text-text-tertiary">暂无交易记录</p>
          <button
            onClick={() => navigate('/add')}
            className="mt-3 px-4 py-2 bg-brand text-white text-sm rounded-xl"
          >
            记一笔
          </button>
        </div>
      )}
    </div>
  );
}
