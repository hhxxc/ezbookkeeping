import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Plus } from 'lucide-react';
import { useApp } from '@/context';
import { formatAmount } from '@/lib/utils';
import { getIcon } from '@/lib/icons';

export default function AccountsPage() {
  const navigate = useNavigate();
  const { state } = useApp();

  const netWorth = useMemo(
    () => state.accounts.reduce((s, a) => s + a.balance, 0),
    [state.accounts]
  );

  const grouped = useMemo(() => {
    const groups: Record<string, typeof state.accounts> = {
      cash: [],
      debit: [],
      credit: [],
      ewallet: [],
    };
    state.accounts.forEach((a) => {
      groups[a.type]?.push(a);
    });
    return groups;
  }, [state.accounts]);

  const typeLabels: Record<string, string> = {
    cash: '现金',
    debit: '借记卡',
    credit: '信用卡',
    ewallet: '电子钱包',
  };

  return (
    <div className="min-h-screen bg-bg pb-8">
      {/* Top Bar */}
      <div className="bg-white px-4 pt-4 pb-3 flex items-center justify-between shadow-xs">
        <button onClick={() => navigate('/')} className="p-2 -ml-2">
          <ChevronLeft size={24} strokeWidth={1.5} className="text-text-primary" />
        </button>
        <h1 className="text-[17px] font-semibold text-text-primary">我的账户</h1>
        <button className="p-2 -mr-2">
          <Plus size={24} strokeWidth={1.5} className="text-text-primary" />
        </button>
      </div>

      {/* Net Worth Card */}
      <div className="mx-5 mt-4 bg-white rounded-2xl shadow-card p-5">
        <p className="text-sm text-text-secondary mb-1">净资产</p>
        <p className="text-[32px] font-din font-bold text-text-primary tracking-wide">
          ¥ {formatAmount(netWorth)}
        </p>
        <div className="flex items-center gap-4 mt-3 pt-3 border-t border-divider">
          <div>
            <p className="text-xs text-text-secondary">本月支出</p>
            <p className="text-sm font-din text-expense mt-0.5">
              ¥ {formatAmount(
                state.transactions
                  .filter((t) => t.date.startsWith(state.selectedMonth) && t.type === 'expense')
                  .reduce((s, t) => s + t.amount, 0)
              )}
            </p>
          </div>
          <div>
            <p className="text-xs text-text-secondary">本月收入</p>
            <p className="text-sm font-din text-income mt-0.5">
              ¥ {formatAmount(
                state.transactions
                  .filter((t) => t.date.startsWith(state.selectedMonth) && t.type === 'income')
                  .reduce((s, t) => s + t.amount, 0)
              )}
            </p>
          </div>
        </div>
      </div>

      {/* Account Groups */}
      <div className="px-5 mt-4 space-y-4">
        {Object.entries(grouped).map(([type, accounts]) => {
          if (accounts.length === 0) return null;
          return (
            <div key={type}>
              <p className="text-xs text-text-tertiary mb-2 px-1">{typeLabels[type]}</p>
              <div className="bg-white rounded-2xl shadow-card overflow-hidden">
                {accounts.map((account, i) => {
                  const Icon = getIcon(account.icon);
                  return (
                    <div key={account.id}>
                      <div className="flex items-center gap-3 px-4 py-3.5">
                        <div
                          className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                          style={{ backgroundColor: account.color + '20' }}
                        >
                          <Icon size={20} strokeWidth={1.5} className="text-text-secondary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-[15px] font-medium text-text-primary">{account.name}</p>
                        </div>
                        <span className={`text-[15px] font-din font-semibold ${
                          account.balance >= 0 ? 'text-text-primary' : 'text-expense'
                        }`}>
                          ¥ {formatAmount(Math.abs(account.balance))}
                        </span>
                      </div>
                      {i < accounts.length - 1 && <div className="h-px bg-divider mx-4" />}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
