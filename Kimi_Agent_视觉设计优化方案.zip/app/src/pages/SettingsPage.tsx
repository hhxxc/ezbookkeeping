import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Eye, Banknote, Tag, Trash2 } from 'lucide-react';
import { useApp } from '@/context';

export default function SettingsPage() {
  const navigate = useNavigate();
  const { state, dispatch } = useApp();

  const settings = [
    {
      icon: Eye,
      label: '金额显示',
      value: state.hideAmounts ? '已隐藏' : '已显示',
      action: () => dispatch({ type: 'TOGGLE_AMOUNT_VISIBILITY' }),
    },
    {
      icon: Banknote,
      label: '月度预算',
      value: state.budget ? `¥ ${state.budget}` : '未设置',
      action: () => {
        const val = prompt('设置月度预算（元）:', state.budget?.toString() || '');
        if (val !== null) {
          dispatch({ type: 'SET_BUDGET', payload: val ? parseFloat(val) : null });
        }
      },
    },
    {
      icon: Tag,
      label: '分类管理',
      value: `${state.categories.length} 个分类`,
      action: () => {},
    },
    {
      icon: Trash2,
      label: '清除数据',
      value: '',
      action: () => {
        if (confirm('确定要清除所有数据吗？此操作不可恢复。')) {
          localStorage.removeItem('nestnote_data');
          window.location.reload();
        }
      },
    },
  ];

  return (
    <div className="min-h-screen bg-bg">
      <div className="bg-white px-4 pt-4 pb-3 flex items-center shadow-xs">
        <button onClick={() => navigate('/')} className="p-2 -ml-2">
          <ChevronLeft size={24} strokeWidth={1.5} className="text-text-primary" />
        </button>
        <h1 className="flex-1 text-center text-[17px] font-semibold text-text-primary pr-8">设置</h1>
      </div>

      <div className="mx-5 mt-4 bg-white rounded-2xl shadow-card overflow-hidden">
        {settings.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.label}
              onClick={item.action}
              className="w-full flex items-center gap-3 px-5 py-4 text-left hover:bg-gray-50 transition-colors"
            >
              <div className="w-10 h-10 rounded-xl bg-bg flex items-center justify-center">
                <Icon size={20} strokeWidth={1.5} className="text-text-secondary" />
              </div>
              <span className="flex-1 text-[15px] text-text-primary">{item.label}</span>
              {item.value && (
                <span className="text-sm text-text-tertiary">{item.value}</span>
              )}
            </button>
          );
        })}
      </div>

      <p className="text-center text-xs text-text-tertiary mt-8">巢记 v1.0</p>
    </div>
  );
}
