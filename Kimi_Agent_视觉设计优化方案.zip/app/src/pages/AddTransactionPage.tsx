import { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useApp } from '@/context';
import { CATEGORY_MAP } from '@/types';
import { generateId } from '@/lib/utils';
import { showToast } from '@/components/Toast';
import CategoryIcon from '@/components/CategoryIcon';
import { Camera } from 'lucide-react';

const numpadKeys = ['7', '8', '9', '4', '5', '6', '1', '2', '3', '.', '0', 'del'];

const parentCategories = Object.values(CATEGORY_MAP).filter((c) => !c.parent);

export default function AddTransactionPage() {
  const navigate = useNavigate();
  const { dispatch } = useApp();
  const [txType, setTxType] = useState<'expense' | 'income'>('expense');
  const [amount, setAmount] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('food');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [account, setAccount] = useState('alipay');
  const [saving, setSaving] = useState(false);

  const handleNumpad = (key: string) => {
    if (key === 'del') {
      setAmount((prev) => prev.slice(0, -1));
    } else if (key === '.') {
      if (!amount.includes('.')) setAmount((prev) => prev + '.');
    } else {
      if (amount.replace('.', '').length < 8) {
        setAmount((prev) => prev + key);
      }
    }
  };

  const handleSave = () => {
    const numAmount = parseFloat(amount);
    if (!numAmount || numAmount <= 0) {
      showToast('请输入金额', 'error');
      return;
    }
    setSaving(true);
    setTimeout(() => {
      dispatch({
        type: 'ADD_TRANSACTION',
        payload: {
          id: generateId(),
          amount: numAmount,
          type: txType,
          category: selectedCategory,
          description: description || CATEGORY_MAP[selectedCategory]?.name || '未分类',
          account,
          date,
          time: new Date().toTimeString().slice(0, 5),
          tags: [],
        },
      });
      setSaving(false);
      showToast('记账成功', 'success');
      navigate('/');
    }, 600);
  };

  const displayAmount = amount || '0';

  return (
    <div className="min-h-screen bg-bg flex flex-col">
      {/* Header */}
      <div className="bg-white px-4 pt-4 pb-3 flex items-center justify-between shadow-xs">
        <button onClick={() => navigate(-1)} className="text-text-secondary text-[15px]">
          取消
        </button>
        <div className="flex items-center bg-bg rounded-lg p-0.5">
          <button
            onClick={() => setTxType('expense')}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${
              txType === 'expense' ? 'bg-expense text-white' : 'text-text-secondary'
            }`}
          >
            支出
          </button>
          <button
            onClick={() => setTxType('income')}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${
              txType === 'income' ? 'bg-income text-white' : 'text-text-secondary'
            }`}
          >
            收入
          </button>
        </div>
        <button
          onClick={handleSave}
          disabled={saving}
          className={`text-[15px] font-medium ${
            saving ? 'text-text-tertiary' : 'text-brand'
          }`}
        >
          {saving ? '保存中' : '保存'}
        </button>
      </div>

      {/* Amount Display */}
      <div className="bg-white px-6 py-8 flex flex-col items-center">
        <p className="text-sm text-text-secondary mb-2">金额</p>
        <div className="flex items-baseline gap-1">
          <span className="text-2xl text-text-primary">¥</span>
          <motion.span
            className={`text-5xl font-din font-bold text-text-primary tracking-wide ${
              !amount ? 'text-text-tertiary' : ''
            }`}
            key={amount}
            initial={{ scale: 1.05 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 500, damping: 30 }}
          >
            {displayAmount}
          </motion.span>
        </div>
      </div>

      {/* Category Selection */}
      <div className="px-4 py-4">
        <p className="text-sm text-text-secondary mb-3">分类</p>
        <div className="grid grid-cols-4 gap-3">
          {parentCategories.map((cat) => (
            <motion.button
              key={cat.key}
              onClick={() => setSelectedCategory(cat.key)}
              className="flex flex-col items-center gap-1.5 py-2"
              whileTap={{ scale: 0.9 }}
              transition={{ type: 'spring', stiffness: 500, damping: 30 }}
            >
              <div
                className={`w-[52px] h-[52px] rounded-[14px] flex items-center justify-center transition-colors ${
                  selectedCategory === cat.key ? '' : 'bg-divider'
                }`}
                style={
                  selectedCategory === cat.key ? { backgroundColor: cat.color } : {}
                }
              >
                <CategoryIcon
                  iconName={cat.icon}
                  color={selectedCategory === cat.key ? cat.color : '#9CA3AF'}
                  size={22}
                  className={selectedCategory === cat.key ? '!bg-white/30' : ''}
                />
              </div>
              <span
                className={`text-xs ${
                  selectedCategory === cat.key ? 'text-brand font-medium' : 'text-text-secondary'
                }`}
              >
                {cat.name}
              </span>
              {selectedCategory === cat.key && (
                <div className="w-1 h-1 rounded-full bg-brand" />
              )}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Details */}
      <div className="px-4 space-y-3 flex-1">
        <div className="flex items-center gap-3 bg-white rounded-xl px-4 py-3">
          <span className="text-sm text-text-secondary w-12">日期</span>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="flex-1 text-sm text-text-primary bg-transparent outline-none"
          />
        </div>
        <div className="flex items-center gap-3 bg-white rounded-xl px-4 py-3">
          <span className="text-sm text-text-secondary w-12">账户</span>
          <select
            value={account}
            onChange={(e) => setAccount(e.target.value)}
            className="flex-1 text-sm text-text-primary bg-transparent outline-none"
          >
            <option value="cash">现金</option>
            <option value="alipay">支付宝</option>
            <option value="wechat">微信支付</option>
            <option value="debit">储蓄卡</option>
            <option value="credit">信用卡</option>
          </select>
        </div>
        <div className="bg-white rounded-xl px-4 py-3">
          <input
            type="text"
            placeholder="添加备注..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full text-sm text-text-primary bg-transparent outline-none"
          />
        </div>
      </div>

      {/* Numpad */}
      <div className="bg-white px-4 pb-6 pt-3">
        <div className="grid grid-cols-3 gap-2">
          {numpadKeys.map((key) => (
            <motion.button
              key={key}
              onClick={() => handleNumpad(key)}
              className="h-12 rounded-xl bg-bg text-[22px] font-medium text-text-primary flex items-center justify-center active:bg-gray-200 transition-colors"
              whileTap={{ scale: 0.92 }}
              transition={{ type: 'spring', stiffness: 500, damping: 30 }}
            >
              {key === 'del' ? (
                <span className="text-sm text-text-secondary">删除</span>
              ) : (
                key
              )}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Camera FAB */}
      <motion.button
        className="fixed bottom-32 right-5 w-10 h-10 rounded-full bg-divider flex items-center justify-center"
        whileTap={{ scale: 0.9 }}
      >
        <Camera size={18} className="text-text-secondary" />
      </motion.button>
    </div>
  );
}
