import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronDown, PieChart, BarChart3, TrendingUp, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useApp, useCategoryBreakdown } from '@/context';
import { formatAmount } from '@/lib/utils';
import CategoryIcon from '@/components/CategoryIcon';
import {
  PieChart as RePieChart, Pie, Cell, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  Area, AreaChart
} from 'recharts';

type ChartType = 'bar' | 'pie' | 'trend';

export default function StatisticsPage() {
  const navigate = useNavigate();
  const { state } = useApp();
  const [chartType, setChartType] = useState<ChartType>('bar');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const { total, breakdown } = useCategoryBreakdown(state.selectedMonth, 'expense');

  const pieData = useMemo(() =>
    breakdown.map((b) => ({
      name: b.name,
      value: b.amount,
      color: b.color,
      key: b.key,
    })),
    [breakdown]
  );

  const trendData = useMemo(() => {
    const months = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date();
      d.setMonth(d.getMonth() - i);
      const m = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const monthTx = state.transactions.filter((t) => t.date.startsWith(m) && t.type === 'expense');
      months.push({
        month: `${d.getMonth() + 1}月`,
        amount: monthTx.reduce((s, t) => s + t.amount, 0),
      });
    }
    return months;
  }, [state.transactions]);

  const maxAmount = Math.max(...breakdown.map((b) => b.amount), 1);

  return (
    <div className="min-h-screen bg-bg pb-8">
      {/* Top Bar */}
      <div className="bg-white px-4 pt-4 pb-3 flex items-center justify-between shadow-xs">
        <button onClick={() => navigate('/')} className="p-2 -ml-2">
          <ChevronLeft size={24} strokeWidth={1.5} className="text-text-primary" />
        </button>
        <button className="flex items-center gap-1 text-[17px] font-semibold text-text-primary">
          分类统计
          <ChevronDown size={18} className="text-text-tertiary" />
        </button>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setChartType('pie')}
            className={`p-2 rounded-lg ${chartType === 'pie' ? 'bg-brand-light text-brand' : 'text-text-tertiary'}`}
          >
            <PieChart size={18} strokeWidth={1.5} />
          </button>
          <button
            onClick={() => setChartType('bar')}
            className={`p-2 rounded-lg ${chartType === 'bar' ? 'bg-brand-light text-brand' : 'text-text-tertiary'}`}
          >
            <BarChart3 size={18} strokeWidth={1.5} />
          </button>
          <button
            onClick={() => setChartType('trend')}
            className={`p-2 rounded-lg ${chartType === 'trend' ? 'bg-brand-light text-brand' : 'text-text-tertiary'}`}
          >
            <TrendingUp size={18} strokeWidth={1.5} />
          </button>
        </div>
      </div>

      {/* Total Overview */}
      <div className="px-5 pt-5 pb-3 flex items-center justify-between">
        <div>
          <p className="text-sm text-text-secondary">总支出</p>
          <p className="text-[32px] font-din font-bold text-text-primary tracking-wide">
            ¥ {formatAmount(total)}
          </p>
        </div>
        <button className="flex items-center gap-1 text-sm text-text-secondary">
          排序方式 <span className="text-brand">金额</span>
          <ChevronDown size={14} />
        </button>
      </div>

      {/* Chart Area */}
      <motion.div
        key={chartType}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="mx-5 bg-white rounded-2xl shadow-card p-4 mb-4 h-64"
      >
        {chartType === 'pie' && (
          <ResponsiveContainer width="100%" height="100%">
            <RePieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={85}
                paddingAngle={2}
                dataKey="value"
                onClick={(_, index) => setSelectedCategory(pieData[index].key)}
              >
                {pieData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.color}
                    opacity={selectedCategory && selectedCategory !== entry.key ? 0.4 : 1}
                  />
                ))}
              </Pie>
              <Tooltip
                formatter={(value: number) => `¥ ${formatAmount(value)}`}
                contentStyle={{ borderRadius: '10px', border: 'none', boxShadow: '0 4px 16px rgba(0,0,0,0.1)' }}
              />
            </RePieChart>
          </ResponsiveContainer>
        )}
        {chartType === 'bar' && (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={breakdown.slice(0, 6)} layout="vertical" margin={{ left: 0, right: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F0F1F3" />
              <XAxis type="number" hide />
              <YAxis dataKey="name" type="category" width={60} tick={{ fontSize: 12, fill: '#6B7280' }} axisLine={false} tickLine={false} />
              <Tooltip
                formatter={(value: number) => `¥ ${formatAmount(value)}`}
                contentStyle={{ borderRadius: '10px', border: 'none', boxShadow: '0 4px 16px rgba(0,0,0,0.1)' }}
              />
              <Bar dataKey="amount" radius={[0, 6, 6, 0]}>
                {breakdown.slice(0, 6).map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}
        {chartType === 'trend' && (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trendData}>
              <defs>
                <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3DC9A0" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#3DC9A0" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#F0F1F3" />
              <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#6B7280' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#9CA3AF' }} axisLine={false} tickLine={false} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
              <Tooltip
                formatter={(value: number) => `¥ ${formatAmount(value)}`}
                contentStyle={{ borderRadius: '10px', border: 'none', boxShadow: '0 4px 16px rgba(0,0,0,0.1)' }}
              />
              <Area type="monotone" dataKey="amount" stroke="#3DC9A0" strokeWidth={3} fillOpacity={1} fill="url(#colorAmount)" />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </motion.div>

      {/* Category List */}
      <div className="mx-5 bg-white rounded-2xl shadow-card overflow-hidden">
        {breakdown.map((cat, i) => (
          <div key={cat.key}>
            <motion.button
              className={`w-full flex items-center gap-3 px-5 py-4 text-left transition-colors ${
                selectedCategory === cat.key ? 'bg-gray-50' : ''
              }`}
              onClick={() => setSelectedCategory(selectedCategory === cat.key ? null : cat.key)}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <CategoryIcon iconName={cat.icon} color={cat.color} size={20} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-[15px] font-medium text-text-primary">{cat.name}</span>
                  <span className="text-[13px] text-text-secondary">{cat.percentage.toFixed(1)}%</span>
                </div>
                {/* Progress Bar */}
                <div className="w-full h-1.5 bg-divider rounded-full overflow-hidden">
                  <motion.div
                    className="h-full rounded-full"
                    style={{ backgroundColor: cat.color }}
                    initial={{ width: 0 }}
                    animate={{ width: `${(cat.amount / maxAmount) * 100}%` }}
                    transition={{ duration: 0.8, delay: i * 0.1, ease: 'easeOut' }}
                  />
                </div>
              </div>
              <div className="text-right flex-shrink-0 flex items-center gap-1">
                <span className="text-[15px] font-din font-semibold text-text-primary">
                  ¥ {formatAmount(cat.amount)}
                </span>
                <ChevronRight size={16} className="text-divider" />
              </div>
            </motion.button>
            {i < breakdown.length - 1 && <div className="h-px bg-divider mx-5" />}
          </div>
        ))}
      </div>

      {breakdown.length === 0 && (
        <div className="text-center py-16 text-text-tertiary">
          <p className="text-sm">本月暂无支出记录</p>
        </div>
      )}
    </div>
  );
}
