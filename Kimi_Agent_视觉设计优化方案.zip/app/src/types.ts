export interface Transaction {
  id: string;
  amount: number;
  type: 'expense' | 'income';
  category: string;
  subcategory?: string;
  description: string;
  account: string;
  date: string;
  time: string;
  tags: string[];
  receiptImage?: string;
}

export interface Category {
  key: string;
  name: string;
  icon: string;
  color: string;
  parent?: string;
}

export interface Account {
  id: string;
  name: string;
  type: 'cash' | 'debit' | 'credit' | 'ewallet';
  balance: number;
  icon: string;
  color: string;
}

export interface AppState {
  transactions: Transaction[];
  selectedMonth: string;
  selectedTab: 'expense' | 'income' | 'balance';
  budget: number | null;
  accounts: Account[];
  categories: Category[];
  hideAmounts: boolean;
}

export type Action =
  | { type: 'ADD_TRANSACTION'; payload: Transaction }
  | { type: 'EDIT_TRANSACTION'; payload: { id: string; updates: Partial<Transaction> } }
  | { type: 'DELETE_TRANSACTION'; payload: string }
  | { type: 'SET_MONTH'; payload: string }
  | { type: 'SET_TAB'; payload: 'expense' | 'income' | 'balance' }
  | { type: 'SET_BUDGET'; payload: number | null }
  | { type: 'ADD_ACCOUNT'; payload: Account }
  | { type: 'TOGGLE_AMOUNT_VISIBILITY' }
  | { type: 'LOAD_STATE'; payload: AppState };

export const CATEGORY_MAP: Record<string, Category> = {
  food: { key: 'food', name: '食品', icon: 'UtensilsCrossed', color: '#F5C6A0' },
  home: { key: 'home', name: '家居用品', icon: 'Sofa', color: '#B8C5D6' },
  baby: { key: 'baby', name: '育儿花销', icon: 'Baby', color: '#D4B8D4' },
  utilities: { key: 'utilities', name: '水电煤气', icon: 'Droplets', color: '#A8D5BA' },
  pet: { key: 'pet', name: '养猫支出', icon: 'Cat', color: '#C8C8C8' },
  clothing: { key: 'clothing', name: '衣服', icon: 'Shirt', color: '#F5B8B8' },
  electronics: { key: 'electronics', name: '电子产品', icon: 'Smartphone', color: '#B8D4E3' },
  service: { key: 'service', name: '家政服务', icon: 'Sparkles', color: '#E3C6A8' },
  transport: { key: 'transport', name: '交通', icon: 'Bus', color: '#A8D5BA' },
  entertainment: { key: 'entertainment', name: '娱乐', icon: 'Gamepad2', color: '#B8D4E3' },
  medical: { key: 'medical', name: '医疗', icon: 'HeartPulse', color: '#F5B8B8' },
  other: { key: 'other', name: '其他', icon: 'MoreHorizontal', color: '#C8C8C8' },
  drink: { key: 'drink', name: '饮料', icon: 'Coffee', color: '#F5C6A0', parent: 'food' },
};

export const TAB_LABELS: Record<string, string> = {
  expense: '支出',
  income: '收入',
  balance: '结余',
};
