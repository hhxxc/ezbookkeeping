# 巢记 — 技术规格文档

## 依赖

| 包名 | 版本 | 用途 |
|------|------|------|
| react | ^19 | UI框架 |
| react-dom | ^19 | DOM渲染 |
| react-router-dom | ^7 | 页面路由（HashRouter） |
| framer-motion | ^12 | 动画系统与手势 |
| recharts | ^2 | 图表组件（饼图/条形/折线） |
| lucide-react | ^0.460 | 线性图标库 |
| tailwindcss | ^3 | 样式系统 |
| @tailwindcss/typography | ^0.5 | Typography插件 |
| clsx | ^2 | 条件类名拼接 |
| tailwind-merge | ^2 | Tailwind类名冲突解决 |
| date-fns | ^4 | 日期处理 |

## 组件清单

### Layout（全局共享）

| 组件 | 来源 | 复用 |
|------|------|------|
| BottomNav | 自定义 | 全局（Home/Transactions/Accounts/Settings页面） |
| FAB | 自定义 | 全局（悬浮在BottomNav上方的记账按钮） |
| PageTransition | 自定义 | 全局（Framer Motion AnimatePresence页面过渡包装） |
| TopBar | 自定义 | Home/Statistics/Transactions/AddTransaction |
| Toast | 自定义 | 全局（固定定位通知） |

### 页面级

| 页面 | 路由 | 说明 |
|------|------|------|
| HomePage | `/` | 首页：收支概览、时间维度卡片、筛选标签 |
| StatisticsPage | `/statistics` | 分类统计：进度条列表、图表视图切换 |
| TransactionsPage | `/transactions` | 交易列表：搜索、日期分组、筛选 |
| AddTransactionPage | `/add` | 记一笔：数字键盘、分类选择、表单 |
| AccountsPage | `/accounts` | 账户管理：净资产卡片、账户列表 |

### 可复用组件

| 组件 | 来源 | 使用位置 |
|------|------|----------|
| AmountDisplay | 自定义 | HomePage/StatisticsPage/TransactionsPage（DIN字体金额展示，含显示/隐藏切换） |
| CategoryIcon | 自定义 | StatisticsPage/TransactionsPage/AddTransactionPage（莫兰迪色图标容器） |
| ProgressBar | 自定义 | StatisticsPage（带动画的水平进度条） |
| RingProgress | 自定义（SVG） | HomePage（圆环预算进度条） |
| MonthPicker | 自定义 | StatisticsPage/TransactionsPage（底部弹出的月份选择器Sheet） |
| SearchBar | 自定义 | TransactionsPage（带热门标签的搜索输入） |
| Numpad | 自定义 | AddTransactionPage（自定义数字键盘） |
| TransactionItem | 自定义 | TransactionsPage/HomePage（交易列表单项，含左滑操作） |
| TimePeriodCard | 自定义 | HomePage（今天/本周/本月/今年卡片项） |
| ExpenseIncomeToggle | 自定义 | HomePage/AddTransactionPage（支出/收入/结余切换标签） |
| CategoryGrid | 自定义 | AddTransactionPage（分类图标网格选择器） |
| DonutChart | recharts | StatisticsPage（环形饼图） |
| BarChartView | recharts | StatisticsPage（水平条形图） |
| LineChartView | recharts | StatisticsPage（趋势折线图） |
| SkeletonLoader | 自定义 | HomePage/TransactionsPage（骨架屏闪烁加载） |

## 动画实现

| 动画 | 库 | 实现方式 | 复杂度 |
|------|-----|----------|--------|
| 页面转场（fade + slideUp） | Framer Motion | AnimatePresence + motion.div 包裹路由出口 | Low |
| 收支标签切换弹性缩放 | Framer Motion | motion.button with spring scale | Low |
| 进度条加载（stagger） | Framer Motion | motion.div width + staggerChildren | Low |
| 时间卡片展开/收起 | Framer Motion | AnimatePresence + motion.div height auto | Medium |
| 饼图扇区外移 | recharts + Framer Motion | recharts activeShape + framer motion x/y offset | Medium |
| 悬浮按钮弹性按压 | Framer Motion | whileHover/whileTap scale + spring | Low |
| 下拉刷新旋转动画 | CSS | @keyframes rotate 配合 transform-origin | Low |
| 骨架屏shimmer | CSS | @keyframes shimmer background-position 移动 | Low |
| 数字输入跳动 | Framer Motion | motion.span scale keyframes on input | Low |
| 月份左右滑动切换 | Framer Motion | drag="x" + onDragEnd 判断方向 + AnimatePresence exit/enter | Medium |
| 交易项左滑操作 | Framer Motion | drag="x" dragConstraints + 底层绝对定位操作按钮 | Medium |
| Toast滑入滑出 | Framer Motion | AnimatePresence + motion.div y/opacity | Low |
| 图表切换淡入淡出 | Framer Motion | AnimatePresence mode="wait" + opacity | Low |
| 保存按钮加载→成功 | Framer Motion | 状态切换动画（spinner → checkmark） | Low |
| 眼睛图标切换 | CSS/Framer | opacity crossfade between Eye/EyeOff | Low |

## 状态与逻辑

### 数据流

使用 React Context + useReducer 管理全局状态，localStorage 持久化。

```
AppContext (Provider)
  ├── transactions[]    — 交易记录数组
  ├── selectedMonth     — 当前选中月份 (YYYY-MM)
  ├── selectedTab       — 'expense' | 'income' | 'balance'
  ├── budget            — 月度预算 (number|null)
  ├── accounts[]        — 账户列表
  ├── categories[]      — 分类配置（含图标、颜色）
  └── dispatch(action)  — 统一action分发
```

### Action 类型

| Action | Payload | 说明 |
|--------|---------|------|
| ADD_TRANSACTION | Transaction | 新增交易 |
| EDIT_TRANSACTION | { id, updates } | 编辑交易 |
| DELETE_TRANSACTION | string (id) | 删除交易 |
| SET_MONTH | string | 切换选中月份 |
| SET_TAB | 'expense' \| 'income' \| 'balance' | 切换收支标签 |
| SET_BUDGET | number \| null | 设置预算 |
| ADD_ACCOUNT | Account | 新增账户 |
| TOGGLE_AMOUNT_VISIBILITY | — | 切换金额显示/隐藏 |

### 派生数据（useMemo）

所有聚合数据通过 useMemo 从 transactions 派生，不做冗余存储：

- `monthlyTotal` — 指定月份总支出/总收入
- `categoryBreakdown` — 按分类汇总的金额与占比
- `dailyTransactions` — 按日期分组的交易
- `timePeriodStats` — 今天/本周/本月/今年的收支统计
- `budgetProgress` — 预算使用百分比

### localStorage 持久化

- 每次 state 变更后自动序列化写入 `localStorage.setItem('nestnote_data')`
- 应用启动时从 localStorage 读取并初始化 state
- 首次访问无数据时注入预置 demo 数据

### 路由

使用 HashRouter（5个路由）：

| 路由 | 页面 | BottomNav显示 |
|------|------|---------------|
| `/` | HomePage | ✅ |
| `/statistics` | StatisticsPage | ✅ |
| `/transactions` | TransactionsPage | ✅ |
| `/add` | AddTransactionPage | ❌（全屏页面） |
| `/accounts` | AccountsPage | ✅ |

### 筛选逻辑

TransactionsPage 的筛选为客户端内存过滤，支持：
- 文本搜索（描述、金额、分类名称模糊匹配）
- 分类筛选（单选/多选）
- 账户筛选
- 日期范围筛选
- 排序方式（日期新→旧、金额大→小）

各筛选条件为 AND 关系，筛选状态保存在页面级 useState 中（非全局）。

## 关键架构决策

### 1. Context 而非 Redux/Zustand

应用数据规模小（个人记账，单用户，月交易 < 500 条），Context + useReducer 足够支撑，避免引入额外依赖。

### 2. Recharts 而非自定义 SVG 图表

饼图/条形图/折线图使用 Recharts 实现（其内置动画和交互），仅圆环进度条（RingProgress）用自定义 SVG（因 Recharts 不直接支持单值圆环）。

### 3. 自定义 Numpad 而非系统键盘

AddTransactionPage 使用全屏自定义数字键盘，确保记账体验的一致性，避免移动端系统键盘弹出的布局跳动问题。

### 4. Sheet 组件自定义实现

底部弹出面板（月份选择器、筛选面板）使用 Framer Motion motion.div + fixed 定位实现，不引入额外 UI 库（已支持 drag 手势关闭）。

### 5. 手势使用原生 Framer Motion

月份左右滑动、交易项左滑操作均使用 Framer Motion 的 drag API 实现，不引入 react-swipeable 等额外库。

## 其他

- 日期处理统一使用 date-fns（本地化、月份计算、周范围）
- 金额格式化：Intl.NumberFormat('zh-CN') 处理千分位和货币符号
- 图标统一从 lucide-react 导入，线性风格，strokeWidth 1.5
- 图片资产：仅空状态插画需要一张 SVG，其余均为代码渲染（图标、图表、进度条）
